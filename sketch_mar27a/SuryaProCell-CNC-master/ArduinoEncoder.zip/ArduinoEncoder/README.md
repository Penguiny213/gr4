# ArduinoRotaryEncoder
RotaryEncoder Library For Arduino
