#!/bin/sh
./CNC
